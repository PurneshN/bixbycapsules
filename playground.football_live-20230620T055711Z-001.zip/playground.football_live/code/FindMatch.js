exports.tests = []
exports.preconditions = []
const allData = require("./data/match");
var dates = require("dates")
var lib = require("./lib/search_util.js");
var console = require('console');
var http = require('http');

exports.function = function(awayScore, minAwayScore, maxAwayScore, awayTeam, homeScore, minHomeScore, maxHomeScore, homeTeam, initialAwayOdd, minInitialAwayOdd, maxInitialAwayOdd, initialDrawOdd, minInitialDrawOdd, maxInitialDrawOdd, initialHomeOdd, minInitialHomeOdd, maxInitialHomeOdd, league, leagueID, minLeagueID, maxLeagueID, liveAwayOdd, minLiveAwayOdd, maxLiveAwayOdd, liveDrawOdd, minLiveDrawOdd, maxLiveDrawOdd, liveHomeOdd, minLiveHomeOdd, maxLiveHomeOdd, matchID, minMatchID, maxMatchID, status) {
  var records = [];
  const options = {
    format: "json",
    headers: {
      'x-rapidapi-key': '5a683c5ddamsh80892bfa9609776p180a3ajsnfaedcecc8a02',
      'x-rapidapi-host': 'sports-live-scores.p.rapidapi.com'
    }
  };
  var response = http.getUrl("https://sports-live-scores.p.rapidapi.com/football/live", options);
  /*var response={  "matches": [
    {
      "Away Score": 3,
      "Away Team": "Slovenia U17",
      "Home Score": 0,
      "Home Team": "Serbia U17",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "U17 European Championship, Group B",
      "League ID": 7953,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11223230",
      "Status": "1st half"
    },
    {
      "Away Score": 1,
      "Away Team": "SC Freiburg",
      "Home Score": 1,
      "Home Team": "VfL Wolfsburg",
      "Initial Away Odd": 17,
      "Initial Draw Odd": 10,
      "Initial Home Odd": 1.07,
      "League": "DFB Pokal, Women",
      "League ID": 11022,
      "Live Away Odd": 17,
      "Live Draw Odd": 10,
      "Live Home Odd": 1.07,
      "Match ID": "11217976",
      "Status": "Halftime"
    },
    {
      "Away Score": 0,
      "Away Team": "KS Burreli",
      "Home Score": 3,
      "Home Team": "Besa Kavajë",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Kategoria e Pare",
      "League ID": 11275,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11246707",
      "Status": "2nd half"
    },
    {
      "Away Score": 1,
      "Away Team": "KF Apolonia Fier",
      "Home Score": 3,
      "Home Team": "Flamurtari FC",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Kategoria e Pare",
      "League ID": 11275,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11246711",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Dinamo Tirana",
      "Home Score": 1,
      "Home Team": "KF Luz i Vogël 2008",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Kategoria e Pare",
      "League ID": 11275,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11246710",
      "Status": "2nd half"
    },
    {
      "Away Score": 2,
      "Away Team": "FK Tomori Berat",
      "Home Score": 1,
      "Home Team": "KF Turbina Cërrik",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Kategoria e Pare",
      "League ID": 11275,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11246708",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "KF Skënderbeu",
      "Home Score": 0,
      "Home Team": "Lushnja",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Kategoria e Pare",
      "League ID": 11275,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11246709",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "NC Magra",
      "Home Score": 0,
      "Home Team": "MC El Bayadh",
      "Initial Away Odd": 5.5,
      "Initial Draw Odd": 3,
      "Initial Home Odd": 1.67,
      "League": "Ligue 1",
      "League ID": 3657,
      "Live Away Odd": 5.5,
      "Live Draw Odd": 3,
      "Live Home Odd": 1.67,
      "Match ID": "11269074",
      "Status": "1st half"
    },
    {
      "Away Score": 2,
      "Away Team": "CS Dock Sud Reserve",
      "Home Score": 2,
      "Home Team": "Argentino Merlo Reserve",
      "Initial Away Odd": 2.88,
      "Initial Draw Odd": 3,
      "Initial Home Odd": 2.3,
      "League": "Camp. De Reser De Primera Division B Metropolitana",
      "League ID": 62405,
      "Live Away Odd": 2.88,
      "Live Draw Odd": 3,
      "Live Home Odd": 2.3,
      "Match ID": "11288773",
      "Status": "2nd half"
    },
    {
      "Away Score": 1,
      "Away Team": "Comunicaciones Reserve",
      "Home Score": 1,
      "Home Team": "CA San Miguel Reserve",
      "Initial Away Odd": 4,
      "Initial Draw Odd": 3.25,
      "Initial Home Odd": 1.8,
      "League": "Camp. De Reser De Primera Division B Metropolitana",
      "League ID": 62405,
      "Live Away Odd": 4,
      "Live Draw Odd": 3.25,
      "Live Home Odd": 1.8,
      "Match ID": "11288774",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Club EL Porvenir",
      "Home Score": 1,
      "Home Team": "Puerto Nuevo Reserves",
      "Initial Away Odd": 2.5,
      "Initial Draw Odd": 3.2,
      "Initial Home Odd": 2.5,
      "League": "Camp. De Reser De Primera Division B Metropolitana",
      "League ID": 62405,
      "Live Away Odd": 2.5,
      "Live Draw Odd": 3.2,
      "Live Home Odd": 2.5,
      "Match ID": "11288785",
      "Status": "2nd half"
    },
    {
      "Away Score": 1,
      "Away Team": "Colón Reserve",
      "Home Score": 3,
      "Home Team": "Barracas Central Reserve",
      "Initial Away Odd": 2.5,
      "Initial Draw Odd": 3,
      "Initial Home Odd": 2.62,
      "League": "Liga Profesional, Reserves",
      "League ID": 41800,
      "Live Away Odd": 2.5,
      "Live Draw Odd": 3,
      "Live Home Odd": 2.62,
      "Match ID": "11050403",
      "Status": "2nd half"
    },
    {
      "Away Score": 1,
      "Away Team": "Arsenal de Sarandí Reserve",
      "Home Score": 1,
      "Home Team": "CA Independiente Reserve",
      "Initial Away Odd": 3.6,
      "Initial Draw Odd": 3.3,
      "Initial Home Odd": 1.91,
      "League": "Liga Profesional, Reserves",
      "League ID": 41800,
      "Live Away Odd": 3.6,
      "Live Draw Odd": 3.3,
      "Live Home Odd": 1.91,
      "Match ID": "11050398",
      "Status": "2nd half"
    },
    {
      "Away Score": 2,
      "Away Team": "Rosario Central Reserve",
      "Home Score": 1,
      "Home Team": "Defensa y Justicia Reserve",
      "Initial Away Odd": 2.4,
      "Initial Draw Odd": 3.2,
      "Initial Home Odd": 2.6,
      "League": "Liga Profesional, Reserves",
      "League ID": 41800,
      "Live Away Odd": 2.4,
      "Live Draw Odd": 3.2,
      "Live Home Odd": 2.6,
      "Match ID": "11050401",
      "Status": "2nd half"
    },
    {
      "Away Score": 2,
      "Away Team": "San Lorenzo Reserve",
      "Home Score": 1,
      "Home Team": "Instituto AC Cordoba Reserves",
      "Initial Away Odd": 2.9,
      "Initial Draw Odd": 3,
      "Initial Home Odd": 2.3,
      "League": "Liga Profesional, Reserves",
      "League ID": 41800,
      "Live Away Odd": 2.9,
      "Live Draw Odd": 3,
      "Live Home Odd": 2.3,
      "Match ID": "11050399",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "ASV Draßburg",
      "Home Score": 0,
      "Home Team": "Wiener Neustädter SC",
      "Initial Away Odd": 2.25,
      "Initial Draw Odd": 3.75,
      "Initial Home Odd": 2.45,
      "League": "Regionalliga East",
      "League ID": 128,
      "Live Away Odd": 2.25,
      "Live Draw Odd": 3.75,
      "Live Home Odd": 2.45,
      "Match ID": "10436355",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "St Michael Bleiburg",
      "Home Score": 0,
      "Home Team": "SV Donau Klagenfurt",
      "Initial Away Odd": 9,
      "Initial Draw Odd": 8.5,
      "Initial Home Odd": 1.12,
      "League": "2. Landesliga Wien",
      "League ID": 42808,
      "Live Away Odd": 9,
      "Live Draw Odd": 8.5,
      "Live Home Odd": 1.12,
      "Match ID": "11288705",
      "Status": "Halftime"
    },
    {
      "Away Score": 0,
      "Away Team": "Güssing",
      "Home Score": 2,
      "Home Team": "ASK Royal Sped Klingenbach",
      "Initial Away Odd": 7.5,
      "Initial Draw Odd": 5.5,
      "Initial Home Odd": 1.25,
      "League": "Burgenlandliga",
      "League ID": 694,
      "Live Away Odd": 7.5,
      "Live Draw Odd": 5.5,
      "Live Home Odd": 1.25,
      "Match ID": "11288697",
      "Status": "1st half"
    },
    {
      "Away Score": 0,
      "Away Team": "Spratzern",
      "Home Score": 0,
      "Home Team": "ASK Mannersdorf",
      "Initial Away Odd": 2,
      "Initial Draw Odd": 4,
      "Initial Home Odd": 2.75,
      "League": "Landesliga NÖ",
      "League ID": 3061,
      "Live Away Odd": 2,
      "Live Draw Odd": 4,
      "Live Home Odd": 2.75,
      "Match ID": "11288698",
      "Status": "1st half"
    },
    {
      "Away Score": 2,
      "Away Team": "Sportunion Sankt Martin",
      "Home Score": 2,
      "Home Team": "Union Donauwell Perg",
      "Initial Away Odd": 2,
      "Initial Draw Odd": 4,
      "Initial Home Odd": 2.75,
      "League": "Oberösterreich Liga",
      "League ID": 42271,
      "Live Away Odd": 2,
      "Live Draw Odd": 4,
      "Live Home Odd": 2.75,
      "Match ID": "11288696",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Mayrhofen",
      "Home Score": 0,
      "Home Team": "SV Vols",
      "Initial Away Odd": 4.2,
      "Initial Draw Odd": 4,
      "Initial Home Odd": 1.6,
      "League": "Tirol Liga",
      "League ID": 93459,
      "Live Away Odd": 4.2,
      "Live Draw Odd": 4,
      "Live Home Odd": 1.6,
      "Match ID": "11288706",
      "Status": "1st half"
    },
    {
      "Away Score": 0,
      "Away Team": "EC São Bernardo SP",
      "Home Score": 0,
      "Home Team": "Red Bull Bragantino",
      "Initial Away Odd": 21,
      "Initial Draw Odd": 10,
      "Initial Home Odd": 1.08,
      "League": "Paulista, Women",
      "League ID": 89490,
      "Live Away Odd": 21,
      "Live Draw Odd": 10,
      "Live Home Odd": 1.08,
      "Match ID": "11228024",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Gazelle FA de Garoua",
      "Home Score": 1,
      "Home Team": "Canon Yaoundé",
      "Initial Away Odd": 3.1,
      "Initial Draw Odd": 3,
      "Initial Home Odd": 2.2,
      "League": "Elite One, Championship Round",
      "League ID": 72808,
      "Live Away Odd": 3.1,
      "Live Draw Odd": 3,
      "Live Home Odd": 2.2,
      "Match ID": "11281512",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "FC Nathalys De Pointe-Noire",
      "Home Score": 2,
      "Home Team": "Patronage Sainte-Anne",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Premier League",
      "League ID": 64524,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11288590",
      "Status": "1st half"
    },
    {
      "Away Score": 0,
      "Away Team": "Dukla Praha",
      "Home Score": 1,
      "Home Team": "Sparta Praha B",
      "Initial Away Odd": 2.25,
      "Initial Draw Odd": 3.5,
      "Initial Home Odd": 2.55,
      "League": "FNL",
      "League ID": 843,
      "Live Away Odd": 5,
      "Live Draw Odd": 3.6,
      "Live Home Odd": 1.67,
      "Match ID": "10609739",
      "Status": "1st half"
    },
    {
      "Away Score": 0,
      "Away Team": "AaB",
      "Home Score": 0,
      "Home Team": "FC København",
      "Initial Away Odd": 5,
      "Initial Draw Odd": 4,
      "Initial Home Odd": 1.67,
      "League": "Pokalen",
      "League ID": 15,
      "Live Away Odd": 5,
      "Live Draw Odd": 2.75,
      "Live Home Odd": 2.05,
      "Match ID": "11259758",
      "Status": "1st half"
    },
    {
      "Away Score": 3,
      "Away Team": "Dayrout SC",
      "Home Score": 1,
      "Home Team": "Al-Nasr Lel-Taa'deen",
      "Initial Away Odd": 3.4,
      "Initial Draw Odd": 2.9,
      "Initial Home Odd": 2.1,
      "League": "Second Division",
      "League ID": 62018,
      "Live Away Odd": 3.4,
      "Live Draw Odd": 2.9,
      "Live Home Odd": 2.1,
      "Match ID": "11288692",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Sporting Alexandria",
      "Home Score": 1,
      "Home Team": "Kafr El Sheikh",
      "Initial Away Odd": 3.25,
      "Initial Draw Odd": 2.8,
      "Initial Home Odd": 2.2,
      "League": "Second Division",
      "League ID": 62018,
      "Live Away Odd": 3.25,
      "Live Draw Odd": 2.8,
      "Live Home Odd": 2.2,
      "Match ID": "11288689",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "La Viena FC",
      "Home Score": 1,
      "Home Team": "Shoban Moslemen Qena",
      "Initial Away Odd": 2,
      "Initial Draw Odd": 3,
      "Initial Home Odd": 3.6,
      "League": "Second Division",
      "League ID": 62018,
      "Live Away Odd": 2,
      "Live Draw Odd": 3,
      "Live Home Odd": 3.6,
      "Match ID": "11288695",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Asyut Petroleum",
      "Home Score": 1,
      "Home Team": "Tamiya Youth Center",
      "Initial Away Odd": 1.67,
      "Initial Draw Odd": 3,
      "Initial Home Odd": 5.5,
      "League": "Second Division",
      "League ID": 62018,
      "Live Away Odd": 1.67,
      "Live Draw Odd": 3,
      "Live Home Odd": 5.5,
      "Match ID": "11288691",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "El Alominiom",
      "Home Score": 1,
      "Home Team": "Telephonat Beni Suef",
      "Initial Away Odd": 1.73,
      "Initial Draw Odd": 3.1,
      "Initial Home Odd": 4.75,
      "League": "Second Division",
      "League ID": 62018,
      "Live Away Odd": 1.73,
      "Live Draw Odd": 3.1,
      "Live Home Odd": 4.75,
      "Match ID": "11288688",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "PIF",
      "Home Score": 1,
      "Home Team": "Inter Turku/2",
      "Initial Away Odd": 2.3,
      "Initial Draw Odd": 3.8,
      "Initial Home Odd": 2.45,
      "League": "Suomen Cup",
      "League ID": 122,
      "Live Away Odd": 2.3,
      "Live Draw Odd": 3.8,
      "Live Home Odd": 2.45,
      "Match ID": "11270560",
      "Status": "2nd half"
    },
    {
      "Away Score": 1,
      "Away Team": "FC Dinamo Zugdidi",
      "Home Score": 2,
      "Home Team": "Tbilisi City",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Liga 4",
      "League ID": 112601,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11175691",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Keflavík IF",
      "Home Score": 3,
      "Home Team": "Stjarnan Garðabær",
      "Initial Away Odd": 3.6,
      "Initial Draw Odd": 4,
      "Initial Home Odd": 1.7,
      "League": "Bikarinn",
      "League ID": 628,
      "Live Away Odd": 3.6,
      "Live Draw Odd": 4,
      "Live Home Odd": 1.7,
      "Match ID": "11256700",
      "Status": "2nd half"
    },
    {
      "Away Score": 3,
      "Away Team": "UMF Grindavík ",
      "Home Score": 0,
      "Home Team": "Valur Reykjavík",
      "Initial Away Odd": 13,
      "Initial Draw Odd": 11,
      "Initial Home Odd": 1.11,
      "League": "Bikarinn",
      "League ID": 628,
      "Live Away Odd": 13,
      "Live Draw Odd": 11,
      "Live Home Odd": 1.11,
      "Match ID": "11256696",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "HK Kopavogur",
      "Home Score": 1,
      "Home Team": "Fjardab/Hottur/Leiknir",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "1. deild, Women",
      "League ID": 79072,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "10976163",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Tractor FC",
      "Home Score": 3,
      "Home Team": "Esteghlal FC",
      "Initial Away Odd": 3.1,
      "Initial Draw Odd": 3.4,
      "Initial Home Odd": 2.05,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 3.1,
      "Live Draw Odd": 3.4,
      "Live Home Odd": 2.05,
      "Match ID": "11227456",
      "Status": "Halftime"
    },
    {
      "Away Score": 0,
      "Away Team": "Aluminium Arak",
      "Home Score": 0,
      "Home Team": "Foolad Khuzestan",
      "Initial Away Odd": 3.4,
      "Initial Draw Odd": 2.75,
      "Initial Home Odd": 2.25,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 3.4,
      "Live Draw Odd": 2.75,
      "Live Home Odd": 2.25,
      "Match ID": "11227444",
      "Status": "Halftime"
    },
    {
      "Away Score": 0,
      "Away Team": "Sanat Naft Abadan",
      "Home Score": 0,
      "Home Team": "Gol Gohar Sirjan",
      "Initial Away Odd": 3.1,
      "Initial Draw Odd": 2.75,
      "Initial Home Odd": 2.25,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 3.1,
      "Live Draw Odd": 2.75,
      "Live Home Odd": 2.25,
      "Match ID": "11227438",
      "Status": "Halftime"
    },
    {
      "Away Score": 0,
      "Away Team": "Malavan Bandar Anzali FC",
      "Home Score": 1,
      "Home Team": "Naft Masjed Soleyman",
      "Initial Away Odd": 1.75,
      "Initial Draw Odd": 3.2,
      "Initial Home Odd": 4.2,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 1.75,
      "Live Draw Odd": 3.2,
      "Live Home Odd": 4.2,
      "Match ID": "11227441",
      "Status": "Halftime"
    },
    {
      "Away Score": 2,
      "Away Team": "Persepolis FC",
      "Home Score": 0,
      "Home Team": "Nassaji Mazandaran FC",
      "Initial Away Odd": 1.33,
      "Initial Draw Odd": 4.1,
      "Initial Home Odd": 8,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 1.33,
      "Live Draw Odd": 4.1,
      "Live Home Odd": 8,
      "Match ID": "11227440",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Mes Rafsanjan FC",
      "Home Score": 0,
      "Home Team": "Paykan",
      "Initial Away Odd": 1.83,
      "Initial Draw Odd": 3.1,
      "Initial Home Odd": 4,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 1.83,
      "Live Draw Odd": 3.1,
      "Live Home Odd": 4,
      "Match ID": "11227459",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Sepahan S.C.",
      "Home Score": 0,
      "Home Team": "Sanat Mes Kerman",
      "Initial Away Odd": 1.5,
      "Initial Draw Odd": 3.5,
      "Initial Home Odd": 6,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 1.5,
      "Live Draw Odd": 3.5,
      "Live Home Odd": 6,
      "Match ID": "11227452",
      "Status": "2nd half"
    },
    {
      "Away Score": 2,
      "Away Team": "Havadar Tehran",
      "Home Score": 2,
      "Home Team": "Zob Ahan",
      "Initial Away Odd": 3.25,
      "Initial Draw Odd": 2.9,
      "Initial Home Odd": 2.15,
      "League": "Persian Gulf Pro League",
      "League ID": 3625,
      "Live Away Odd": 3.25,
      "Live Draw Odd": 2.9,
      "Live Home Odd": 2.15,
      "Match ID": "11227436",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Moghayer Al Sarhan",
      "Home Score": 0,
      "Home Team": "FC Maan",
      "Initial Away Odd": 3,
      "Initial Draw Odd": 3.1,
      "Initial Home Odd": 2.2,
      "League": "Shield Cup",
      "League ID": 55378,
      "Live Away Odd": 3,
      "Live Draw Odd": 3.1,
      "Live Home Odd": 2.2,
      "Match ID": "11288699",
      "Status": "1st half"
    },
    {
      "Away Score": 1,
      "Away Team": "FS Jelgava",
      "Home Score": 2,
      "Home Team": "SK Super Nova",
      "Initial Away Odd": 2.05,
      "Initial Draw Odd": 3.5,
      "Initial Home Odd": 2.9,
      "League": "Virsliga",
      "League ID": 1279,
      "Live Away Odd": 2.05,
      "Live Draw Odd": 3.5,
      "Live Home Odd": 2.9,
      "Match ID": "11070097",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "FK Metta",
      "Home Score": 0,
      "Home Team": "BFC Daugava Daugavpils",
      "Initial Away Odd": 2.15,
      "Initial Draw Odd": 3.2,
      "Initial Home Odd": 3,
      "League": "Virsliga",
      "League ID": 1279,
      "Live Away Odd": 2.15,
      "Live Draw Odd": 3.2,
      "Live Home Odd": 3,
      "Match ID": "11070099",
      "Status": "1st half"
    },
    {
      "Away Score": 2,
      "Away Team": "Al Ahly Benghazi",
      "Home Score": 1,
      "Home Team": "Al Soqour Tobruk",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Premier League Group 1",
      "League ID": 91212,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11241292",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Al Tahaddy Benghazi SC",
      "Home Score": 0,
      "Home Team": "Darnes Derna SC",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Premier League Group 1",
      "League ID": 91212,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11241293",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Al Tayaran Benina",
      "Home Score": 1,
      "Home Team": "Al Wahda Arabia Benghazi",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "First Division - Group 3",
      "League ID": 97353,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11265938",
      "Status": "2nd half"
    },
    {
      "Away Score": 1,
      "Away Team": "Al Faluja Tripoli SCS",
      "Home Score": 0,
      "Home Team": "Abelashhar SC",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "First Division - Group 4",
      "League ID": 97354,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11265944",
      "Status": "Halftime"
    },
    {
      "Away Score": 1,
      "Away Team": "Rafiq Surman FC",
      "Home Score": 1,
      "Home Team": "Al Shat Tripoli SC",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "First Division - Group 4",
      "League ID": 97354,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11265943",
      "Status": "Halftime"
    },
    {
      "Away Score": 0,
      "Away Team": "PSV Eindhoven",
      "Home Score": 2,
      "Home Team": "FC Twente Vrouwen",
      "Initial Away Odd": 7.5,
      "Initial Draw Odd": 5,
      "Initial Home Odd": 1.29,
      "League": "KNVB Beker, Women",
      "League ID": 63918,
      "Live Away Odd": 7.5,
      "Live Draw Odd": 5,
      "Live Home Odd": 1.29,
      "Match ID": "11217978",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Doma United FC",
      "Home Score": 1,
      "Home Team": "Rivers United",
      "Initial Away Odd": 8,
      "Initial Draw Odd": 3.6,
      "Initial Home Odd": 1.4,
      "League": "Professional Football League, Group B",
      "League ID": 70952,
      "Live Away Odd": 8,
      "Live Draw Odd": 3.6,
      "Live Home Odd": 1.4,
      "Match ID": "11276414",
      "Status": "1st half"
    },
    {
      "Away Score": 1,
      "Away Team": "Alania-2 Vladikavkaz",
      "Home Score": 0,
      "Home Team": "Dinamo Stavropol",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "2. Liga, Group 1, Relegation Round",
      "League ID": 114422,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11260608",
      "Status": "1st half"
    },
    {
      "Away Score": 0,
      "Away Team": "Akademia Football Tambov",
      "Home Score": 2,
      "Home Team": "FC Metallurg-Oskol",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Championship SFF Center",
      "League ID": 102089,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11190960",
      "Status": "2nd half"
    },
    {
      "Away Score": 2,
      "Away Team": "Umeå",
      "Home Score": 5,
      "Home Team": "Sollentuna FF",
      "Initial Away Odd": 2.7,
      "Initial Draw Odd": 3.5,
      "Initial Home Odd": 2.2,
      "League": "Ettan, Norra",
      "League ID": 4302,
      "Live Away Odd": 2.7,
      "Live Draw Odd": 3.5,
      "Live Home Odd": 2.2,
      "Match ID": "10973435",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Åtvidabergs FF",
      "Home Score": 2,
      "Home Team": "Eskilsminne IF",
      "Initial Away Odd": 3.6,
      "Initial Draw Odd": 3.3,
      "Initial Home Odd": 1.91,
      "League": "Ettan, Sodra",
      "League ID": 4301,
      "Live Away Odd": 3.6,
      "Live Draw Odd": 3.3,
      "Live Home Odd": 1.91,
      "Match ID": "10972902",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Oskarshamns AIK",
      "Home Score": 5,
      "Home Team": "IK Oddevold",
      "Initial Away Odd": 6.5,
      "Initial Draw Odd": 4.33,
      "Initial Home Odd": 1.36,
      "League": "Ettan, Sodra",
      "League ID": 4301,
      "Live Away Odd": 6.5,
      "Live Draw Odd": 4.33,
      "Live Home Odd": 1.36,
      "Match ID": "10972907",
      "Status": "2nd half"
    },
    {
      "Away Score": 4,
      "Away Team": "Gottne IF",
      "Home Score": 0,
      "Home Team": "Storfors AIK",
      "Initial Away Odd": 1.91,
      "Initial Draw Odd": 3.75,
      "Initial Home Odd": 3.2,
      "League": "Division 2, Norrland",
      "League ID": 409,
      "Live Away Odd": 1.91,
      "Live Draw Odd": 3.75,
      "Live Home Odd": 3.2,
      "Match ID": "11022311",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "Grebbestads IF",
      "Home Score": 1,
      "Home Team": "Herrestads AIF",
      "Initial Away Odd": 2.15,
      "Initial Draw Odd": 3.75,
      "Initial Home Odd": 2.62,
      "League": "Division 2, Norra Gotaland",
      "League ID": 14775,
      "Live Away Odd": 2.15,
      "Live Draw Odd": 3.75,
      "Live Home Odd": 2.62,
      "Match ID": "11021755",
      "Status": "2nd half"
    },
    {
      "Away Score": 0,
      "Away Team": "PFK Andijon",
      "Home Score": 0,
      "Home Team": "Navbahor Namangan",
      "Initial Away Odd": null,
      "Initial Draw Odd": null,
      "Initial Home Odd": null,
      "League": "Cup",
      "League ID": 56346,
      "Live Away Odd": null,
      "Live Draw Odd": null,
      "Live Home Odd": null,
      "Match ID": "11290629",
      "Status": "2nd half"
    }  ]
  
}*/

  console.log("response");
  console.log(response);
  responseArray=response;
  console.log(response.matches.slice(1));

const responseArray = response.matches.slice(1).map((match) => {
    const { awayScore, minAwayScore, maxAwayScore, awayTeam, homeScore, minHomeScore, maxHomeScore, homeTeam, initialAwayOdd, minInitialAwayOdd, maxInitialAwayOdd, initialDrawOdd, minInitialDrawOdd, maxInitialDrawOdd, initialHomeOdd, minInitialHomeOdd, maxInitialHomeOdd, league, leagueID, minLeagueID, maxLeagueID, liveAwayOdd, minLiveAwayOdd, maxLiveAwayOdd, liveDrawOdd, minLiveDrawOdd, maxLiveDrawOdd, liveHomeOdd, minLiveHomeOdd, maxLiveHomeOdd, matchID, minMatchID, maxMatchID, status} = match;
    return {
      awayScore:match["Away Score"],
      awayTeam: match["Away Team"],
      homeScore: match["Home Score"],
      homeTeam: match["Home Team"],
      initialAwayOdd:match["Initial Away Odd"],
      initialDrawOdd:match["Initial Draw Odd"],
      initialHomeOdd:match["Initial Home Odd"],
      league:match["League"],
      leagueID: match["League ID"],
      liveAwayOdd:match["Live Away Odd"],
      liveDrawOdd:match["Live Draw Odd"],
      liveHomeOdd:match["Live Home Odd"],
      matchID:match["Match ID"],
      status:match["Status"],
    };
  });
/*
  response.list.slice(1).forEach((match) => {
  var team = {
    awayScore: match.teamName,
    minAwayScore: match.teamSName,
    awayTeam: match.teamId,
    homeScore: match.countryName
  };

  records.push(team);
});

console.log(records);

   
    console.log(responseArray);
  responseArray.forEach((match) => {
    const playerObj = {
      awayScore: awayScore,
      awayTeam: awayTeam
    };
    records.push(playerObj);
  });
  console.log(records);
  */
  records=responseArray;

  if (awayScore) {
    records = records.filter(record => record.awayScore && record.awayScore == awayScore)
  }
  if (minAwayScore) {
    records = records.filter(record => record.awayScore && record.awayScore >= minAwayScore)
  }
  if (maxAwayScore) {
    records = records.filter(record => record.awayScore && record.awayScore <= maxAwayScore)
  }
  if (awayTeam) {
    records = records.filter(record => record.awayTeam && record.awayTeam.toLowerCase().indexOf(awayTeam.toLowerCase()) >= 0)
  }
  if (homeScore) {
    records = records.filter(record => record.homeScore && record.homeScore == homeScore)
  }
  if (minHomeScore) {
    records = records.filter(record => record.homeScore && record.homeScore >= minHomeScore)
  }
  if (maxHomeScore) {
    records = records.filter(record => record.homeScore && record.homeScore <= maxHomeScore)
  }
  if (homeTeam) {
    records = records.filter(record => record.homeTeam && record.homeTeam.toLowerCase().indexOf(homeTeam.toLowerCase()) >= 0)
  }
  if (initialAwayOdd) {
    records = records.filter(record => record.initialAwayOdd && record.initialAwayOdd == initialAwayOdd)
  }
  if (minInitialAwayOdd) {
    records = records.filter(record => record.initialAwayOdd && record.initialAwayOdd >= minInitialAwayOdd)
  }
  if (maxInitialAwayOdd) {
    records = records.filter(record => record.initialAwayOdd && record.initialAwayOdd <= maxInitialAwayOdd)
  }
  if (initialDrawOdd) {
    records = records.filter(record => record.initialDrawOdd && record.initialDrawOdd == initialDrawOdd)
  }
  if (minInitialDrawOdd) {
    records = records.filter(record => record.initialDrawOdd && record.initialDrawOdd >= minInitialDrawOdd)
  }
  if (maxInitialDrawOdd) {
    records = records.filter(record => record.initialDrawOdd && record.initialDrawOdd <= maxInitialDrawOdd)
  }
  if (initialHomeOdd) {
    records = records.filter(record => record.initialHomeOdd && record.initialHomeOdd == initialHomeOdd)
  }
  if (minInitialHomeOdd) {
    records = records.filter(record => record.initialHomeOdd && record.initialHomeOdd >= minInitialHomeOdd)
  }
  if (maxInitialHomeOdd) {
    records = records.filter(record => record.initialHomeOdd && record.initialHomeOdd <= maxInitialHomeOdd)
  }
  if (league) {
    records = records.filter(record => record.league && record.league.toLowerCase().indexOf(league.toLowerCase()) >= 0)
  }
  if (leagueID) {
    records = records.filter(record => record.leagueID && record.leagueID == leagueID)
  }
  if (minLeagueID) {
    records = records.filter(record => record.leagueID && record.leagueID >= minLeagueID)
  }
  if (maxLeagueID) {
    records = records.filter(record => record.leagueID && record.leagueID <= maxLeagueID)
  }
  if (liveAwayOdd) {
    records = records.filter(record => record.liveAwayOdd && record.liveAwayOdd == liveAwayOdd)
  }
  if (minLiveAwayOdd) {
    records = records.filter(record => record.liveAwayOdd && record.liveAwayOdd >= minLiveAwayOdd)
  }
  if (maxLiveAwayOdd) {
    records = records.filter(record => record.liveAwayOdd && record.liveAwayOdd <= maxLiveAwayOdd)
  }
  if (liveDrawOdd) {
    records = records.filter(record => record.liveDrawOdd && record.liveDrawOdd == liveDrawOdd)
  }
  if (minLiveDrawOdd) {
    records = records.filter(record => record.liveDrawOdd && record.liveDrawOdd >= minLiveDrawOdd)
  }
  if (maxLiveDrawOdd) {
    records = records.filter(record => record.liveDrawOdd && record.liveDrawOdd <= maxLiveDrawOdd)
  }
  if (liveHomeOdd) {
    records = records.filter(record => record.liveHomeOdd && record.liveHomeOdd == liveHomeOdd)
  }
  if (minLiveHomeOdd) {
    records = records.filter(record => record.liveHomeOdd && record.liveHomeOdd >= minLiveHomeOdd)
  }
  if (maxLiveHomeOdd) {
    records = records.filter(record => record.liveHomeOdd && record.liveHomeOdd <= maxLiveHomeOdd)
  }
  if (matchID) {
    records = records.filter(record => record.matchID && record.matchID == matchID)
  }
  if (minMatchID) {
    records = records.filter(record => record.matchID && record.matchID >= minMatchID)
  }
  if (maxMatchID) {
    records = records.filter(record => record.matchID && record.matchID <= maxMatchID)
  }
  if (status) {
    records = records.filter(record => record.status && record.status.toLowerCase().indexOf(status.toLowerCase()) >= 0)
  }
  return records
}