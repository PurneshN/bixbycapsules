
exports.tests = [];
exports.preconditions = [];
//let allData = require("./data/player");
var dates = require("dates");
var lib = require("./lib/search_util.js");
var console = require('console');
var http = require('http');
/*
module.exports.function = function(name, imageId, id, battingStyle, bowlingStyle) {
  const options = {
    format: "json",
    headers: {
      'x-rapidapi-key': '61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130',
      'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com',
      // Add any required headers here, e.g., API key
      "API_KEY" : "61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130"
    },
  };
  const response =  http.getUrl("https://cricbuzz-cricket.p.rapidapi.com/teams/v1/2/players", options);
  var players = [];
  // Add categories
  players.push({ $id: 0, name: "BATSMEN", imageId: "174146" });
  players.push({ $id: 11, name: "ALL ROUNDER", imageId: "174146" });
  players.push({ $id: 16, name: "WICKET KEEPER", imageId: "174146" });
  players.push({ $id: 21, name: "BOWLER", imageId: "174146" });

  let idCounter = 1;
  const responseArray = JSON.parse(response);
  responseArray.forEach((player) => {
        const playerObj = {
          $id: idCounter,
          name: player.name,
          imageId: player.imageId,
          id: player.id,
          battingStyle: player.battingStyle,
          bowlingStyle: player.bowlingStyle,
        };
    players.push(playerObj);
    idCounter++;
  });

  if (name) {
    players = players.filter(players => players.name && players.name.toLowerCase().indexOf(name.toLowerCase()) >= 0)
  }
  if (imageId) {
    players = players.filter(players => players.imageId && players.imageId == imageId)
  }
  if (id) {
    players = players.filter(players => players.id && players.id == id)
  }
  if (battingStyle) {
    players = players.filter(players => players.battingStyle && players.battingStyle.toLowerCase().indexOf(battingStyle.toLowerCase()) >= 0)
  }
  if (bowlingStyle) {
    players = players.filter(players => players.bowlingStyle && players.bowlingStyle.toLowerCase().indexOf(bowlingStyle.toLowerCase()) >= 0)
  }
  return players
}
  */
  exports.tests = [];
exports.preconditions = [];
var tid="2";

//console.log("hello world");
module.exports.function = function(name, imageId, id, battingStyle, bowlingStyle, teamId ) {
  console.log("hello world 0.1");
  const options = {
    format: "json",
    headers: {
      'x-rapidapi-key': '61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130',
      'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com',
      "API_KEY": "61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130"
    }
  };
  console.log("hello world 1.0");
  var url2="https://cricbuzz-cricket.p.rapidapi.com/teams/v1/2/players"
const baseUrl = 'https://cricbuzz-cricket.p.rapidapi.com/teams/v1/';
if(teamId)
{
 tid = teamId;
}
const path2 = '/players';

var url = baseUrl+tid+path2;
console.log(url)

  var response = http.getUrl(url, options);
  var players = [];
  /*
  players.push({ $id: 0, name: "BATSMEN", imageId: "174146" });
  players.push({ $id: 11, name: "ALL ROUNDER", imageId: "174146" });
  players.push({ $id: 16, name: "WICKET KEEPER", imageId: "174146" });
  players.push({ $id: 21, name: "BOWLER", imageId: "174146" });
  */
  let idCounter = 1;
  console.log(response["player"]);
  console.log("hello world 2.0");
  /*
 var responseArray = JSON.parse(response["player"]);
  
  responseArray.forEach((player) => {
    const playerObj = {
      $id: idCounter,
      name: player.name,
      imageId: player.imageId,
      id: player.id,
      battingStyle: player.battingStyle,
      bowlingStyle: player.bowlingStyle,
    };
    players.push(playerObj);
    idCounter++;
  });*/
  
  const responseArray = response.player.slice(1).map((player) => {
  const { id, name, imageId, battingStyle, bowlingStyle } = player;
  return {
    $id: response.player.indexOf(player),
    name: player.name,
      imageId: player.imageId,
      id: player.id,
      battingStyle: player.battingStyle,
      bowlingStyle: player.bowlingStyle,
  };
});


responseArray.forEach((player) => {
  const playerObj = {
    $id: idCounter,
    name: player.name,
    imageId: player.imageId,
    id: player.id,
    battingStyle: player.battingStyle,
    bowlingStyle: player.bowlingStyle,
  };
  players.push(playerObj);
  idCounter++;
});

console.log(players)
players=players.filter(player => player.name && player.name.indexOf("BOWLER"));
  players=players.filter(player => player.name && player.name.indexOf("ALL ROUNDER"));
  players=players.filter(player => player.name && player.name.indexOf("WICKET KEEPER"));
var playerz=players;
  if (name) {
    players =  players.filter(player => player.name && player.name.toLowerCase().indexOf(name.toLowerCase())>= 0);
  }
  if (imageId) {
    players = players.filter(player => player.imageId && player.imageId === imageId);
  }
  if (id) {
    players = players.filter(player => player.id && player.id === id);
  }
  if (battingStyle) {
    players = players.filter(player => player.battingStyle && player.battingStyle.toLowerCase().indexOf(battingStyle.toLowerCase())>= 0);
  }
  if (bowlingStyle) {
    players = players.filter(player => player.bowlingStyle && player.bowlingStyle.toLowerCase().indexOf(bowlingStyle.toLowerCase())>= 0);
  }
  

  return players;
}
