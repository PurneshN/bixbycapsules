// exports.tests = []
// exports.preconditions = []
// const allData = require("./data/list");
var dates = require("dates")
var lib = require("./lib/search_util.js");
var console = require('console');
var http = require('http');

exports.function = function(teamName, teamId, teamSName, imageId, countryName, seoTitle, webURL) {
  var records = [];
  const options = {
    format: "json",
    headers: {
      'x-rapidapi-key': '5a683c5ddamsh80892bfa9609776p180a3ajsnfaedcecc8a02',
      'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com'
    }
  };
  var response = http.getUrl("https://cricbuzz-cricket.p.rapidapi.com/teams/v1/international", options);
  
  console.log("response");
  console.log(response);
  responseArray=response;

  const responseArray = response.list.slice(1).map((list) => {
    const { teamId,teamName,teamSName,imageId} = list;
    return {
      teamName: teamName,
      teamSName: teamSName,
      teamId: teamId,
      countryName: countryName
    };
  });
   console.log(response.list.slice(1));
console.log(responseArray);
  responseArray.forEach((list) => {
    const playerObj = {
      teamName: list.teamName,
      teamSName: list.teamSName,
      teamId: list.teamId,
      countryName: list.countryName
    };
    records.push(playerObj);
  });
  console.log(records);
  if (teamName) {
    records = records.filter(record => record.teamName && record.teamName.toLowerCase().indexOf(teamName.toLowerCase()) >= 0)
  }
  if (teamId) {
    records = records.filter(record => record.teamId && record.teamId == teamId)
  }
  if (teamSName) {
    records = records.filter(record => record.teamSName && record.teamSName.toLowerCase().indexOf(teamSName.toLowerCase()) >= 0)
  }
  console.log(records);
  return records;
}
