
// var url = "https://cricbuzz-cricket.p.rapidapi.com/teams/v1/2/players"
// var API_KEY = "61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130"
// 
// var console = require('console')
// var config = require('config')
// var console = require('console')
// const fetch = require('node-fetch');
// const options = {
//   method: 'GET',
//   headers: {
//     'x-rapidapi-key': '61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130',
//     'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com',
//     'useQueryString': true
//   }
// };
// fetch('https://cricbuzz-cricket.p.rapidapi.com/teams/v1/2/players', options)
//   .then(response => {
//      response.json();
//   })
//   .then(data => {
//     // Extract player data from the response
//     const players = data.players.map(player => ({
//       id: player.id,
//       name: player.name,
//       imageId: player.image_id,
//       battingStyle: player.batting_style,
//       bowlingStyle: player.bowling_style
//     }));

//     console.log(players);
//   })
//   .catch(error => {
//     console.error('There was a problem with the fetch operation:', error);
//   });

//var url = "https://cricbuzz-cricket.p.rapidapi.com/teams/v1/2/players"
// var API_KEY = "61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130"
// var http = require('http')
// var console = require('console')
// var config = require('config')
// var console = require('console')
// // const fetch = require('node-fetch');
// const options = {
//   method: 'GET',
//   headers: {
//     'x-rapidapi-key': '61df6c5c30msh2d302590d7be1d2p18d095jsn4bc385825130',
//     'x-rapidapi-host': 'cricbuzz-cricket.p.rapidapi.com',
//     'useQueryString': true
//   }
// }

//   module.exports=players;




// module.exports = [
// {"$id":0,"name":"BATSMEN","imageId":"174146"},
// {"$id":1,"name":"Virat Kohli","imageId":"244980","id":"1413","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm medium"},
// {"$id":2,"name":"Rohit Sharma","imageId":"244982","id":"576","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm offbreak"},
// {"$id":3,"name":"Shikhar Dhawan","imageId":"170660","id":"1446","battingStyle":"Left-hand bat","bowlingStyle":"Right-arm offbreak"},
// {"$id":4,"name":"Shubman Gill","imageId":"171042","id":"11808","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm offbreak"},
// {"$id":5,"name":"Shreyas Iyer","imageId":"171024","id":"9428","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm legbreak"},
// {"$id":6,"name":"Manish Pandey","imageId":"171022","id":"1836","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm medium"},
// {"$id":7,"name":"Mayank Agarwal","imageId":"171091","id":"2195","battingStyle":"Right-hand bat"},
// {"$id":8,"name":"Prithvi Shaw","imageId":"171030","id":"12094","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm offbreak"},
// {"$id":9,"name":"Cheteshwar Pujara","imageId":"153263","id":"1448","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm legbreak"},
// {"$id":10,"name":"Ajinkya Rahane","imageId":"171082","id":"1447","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm medium"},
// {"$id":11,"name":"ALL ROUNDER","imageId":"174146"},
// {"$id":12,"name":"Hardik Pandya","imageId":"244973","id":"9647","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm fast-medium"},
// {"$id":13,"name":"Hanuma Vihari","imageId":"171080","id":"8424","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm offbreak"},
// {"$id":14,"name":"Ravindra Jadeja","imageId":"170670","id":"587","battingStyle":"Left-hand bat","bowlingStyle":"Left-arm orthodox"},
// {"$id":15,"name":"Ravichandran Ashwin","imageId":"244976","id":"1593","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm offbreak"},
// {"$id":16,"name":"WICKET KEEPER","imageId":"174146"},
// {"$id":17,"name":"KL Rahul","imageId":"244975","id":"8733","battingStyle":"Right-hand bat"},
// {"$id":18,"name":"Sanju Samson","imageId":"226289","id":"8271","battingStyle":"Right-hand bat"},
// {"$id":19,"name":"Wriddhiman Saha","imageId":"171058","id":"1465","battingStyle":"Right-hand bat"},
// {"$id":20,"name":"Rishabh Pant","imageId":"244978","id":"10744","battingStyle":"Left-hand bat"},
// {"$id":21,"name":"BOWLER","imageId":"174146"},
// {"$id":22,"name":"Mohammed Shami","imageId":"244977","id":"7909","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm fast-medium"},
// {"$id":23,"name":"Jasprit Bumrah","imageId":"170685","id":"9311","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm fast"},
// {"$id":24,"name":"Kuldeep Yadav","imageId":"170683","id":"8292","battingStyle":"Left-hand bat","bowlingStyle":"Left-arm chinaman"},
// {"$id":25,"name":"Yuzvendra Chahal","imageId":"244981","id":"7910","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm legbreak"},
// {"$id":26,"name":"Navdeep Saini","imageId":"226400","id":"9715","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm fast"},
// {"$id":27,"name":"Shardul Thakur","imageId":"226224","id":"8683","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm fast-medium"},
// {"$id":28,"name":"Umesh Yadav","imageId":"153874","id":"1858","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm fast"},
// {"$id":29,"name":"Mohammed Siraj","imageId":"171039","id":"10808","battingStyle":"Right-hand bat","bowlingStyle":"Right-arm fast-medium"}
// ];